import os
import streamlit as st
from google import genai
from google.genai import types

st.set_page_config(page_title="Why The Code Is Like This", page_icon="🔎", layout="wide")

st.title("Why The Code Is Like This")
st.caption("A prototype for evidence-aware explanations of code rationale")

st.info(
    "This tool generates hypotheses from the context you provide. "
    "It cannot know an author's original intention unless the supplied evidence supports that conclusion."
)

with st.sidebar:
    st.header("How to use")
    st.markdown(
        "1. Paste a code snippet.\n"
        "2. Add commit, pull-request, issue, or diff context if available.\n"
        "3. Generate an explanation.\n"
        "4. Verify each evidence claim against its source."
    )
    st.warning("Do not paste passwords, API keys, personal data, or private code without permission.")

code = st.text_area(
    "Code snippet",
    height=240,
    placeholder="Paste the relevant code here...",
)
context = st.text_area(
    "Repository context (recommended)",
    height=180,
    placeholder=(
        "Paste relevant commit messages, pull-request discussion, issue text, "
        "diff, code comments, or documentation. Label where each item came from."
    ),
)
question = st.text_input(
    "What do you want to understand?",
    value="Why might this code have been designed this way?",
)

if st.button("Explain with evidence", type="primary", use_container_width=True):
    if not code.strip():
        st.error("Please paste a code snippet first.")
    else:
        api_key = os.getenv("GEMINI_API_KEY", "").strip()
        if not api_key:
            st.error(
                "GEMINI_API_KEY is not set. Add it as an environment variable and restart Streamlit. "
                "Never paste the key into this page or commit it to Git."
            )
        else:
            model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
            prompt = f"""
You are helping a developer understand code rationale. Use only the material provided below.
Do not invent repository history, authors' intentions, benchmark results, sources, or facts.
If context is missing, explicitly say that the rationale cannot be established from the available material.
Separate the answer into these sections:

1. **What the code does** — describe observable behaviour.
2. **Direct evidence** — list exact supplied context that supports a claim; quote short fragments and identify their source label when available. If there is no direct evidence, say "No direct rationale evidence supplied."
3. **Reasonable inferences** — possible explanations, clearly labelled as inferences, with confidence (low/medium/high) and why.
4. **Unknowns to verify** — questions that need a human, author, tests, issue, or history to answer.
5. **Next verification steps** — concrete commands or checks where relevant; do not pretend to have run them.
6. **Potential risks or alternatives** — only where justified by the provided code/context.

Never turn an inference into evidence. Never state that you inspected a repository or ran tests. Do not make unsupported claims. Keep the answer practical and concise.

User's question:
{question}

CODE:
```text
{code}
```

REPOSITORY CONTEXT:
```text
{context if context.strip() else "No repository context was supplied."}
```
"""
            try:
                client = genai.Client(api_key=api_key)
                with st.spinner("Generating a draft explanation..."):
                    response = client.models.generate_content(
                        model=model,
                        contents=prompt,
                        config=types.GenerateContentConfig(temperature=0.2),
                    )
                st.subheader("Draft explanation")
                st.markdown(response.text or "The model returned no text.")
                st.subheader("Human verification checklist")
                checks = [
                    "I opened the cited commit, issue, PR, or documentation myself.",
                    "Any quoted text matches the source exactly.",
                    "I separated direct evidence from inference.",
                    "I did not treat the model's confidence as proof.",
                    "I recorded unanswered questions instead of guessing.",
                ]
                for item in checks:
                    st.checkbox(item, key="check_" + str(checks.index(item)))
                st.caption(
                    "Review the result before using it. This prototype does not independently verify "
                    "repository sources or execute tests."
                )
            except Exception as exc:
                st.error(
                    "The request failed. Check your API key, model access, internet connection, "
                    "and installed package version. Technical details: " + str(exc)
                )

with st.expander("Example of good evidence-aware reasoning"):
    st.markdown(
        "**Evidence:** The supplied commit message says, “Cache the parsed schema to avoid repeated parsing.”\n\n"
        "**Inference:** The cache was likely added to reduce repeated parsing work. This is supported by "
        "the commit message, but performance impact still needs measurement.\n\n"
        "**Unknown:** We do not know how large the speed improvement is unless benchmark data is supplied."
    )
