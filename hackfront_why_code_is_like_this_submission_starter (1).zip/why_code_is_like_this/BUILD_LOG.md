# hackFront Builder Lab — Build Log
## Project: Why The Code Is Like This
**Theme:** AI & Developer Tools  
**Status:** Draft; user research and usability testing still need to be completed.

> Important: Do not submit planned interviews or tests as if they already happened. Replace the TODO fields with actual notes and dates.

---

# Entry 1 — Theme, problem statement, intended build, leverage map

## Theme
AI & Developer Tools.

## Problem statement — Version 1
Developers joining an existing software project may struggle to understand why particular code decisions were made. The relevant reasoning can be scattered across commit messages, pull requests, documentation, and comments. Reconstructing that context may slow onboarding and maintenance, but the frequency and impact of this problem still need validation.

## Intended build
A web tool that takes a code snippet plus available repository context and drafts an explanation with evidence, inferences, and unknowns separated.

## Leverage map
| Task | Mode | Reason |
|---|---|---|
| Draft interview questions | Automation | AI drafts; human reviews |
| Explore problem framings | Augmentation | AI suggests; human investigates |
| Compare current tools | Augmentation | AI organizes; human verifies sources |
| Choose user/problem | Human-led | Requires evidence and judgement |
| Draft UI and prompt | Augmentation | AI helps; human decides |
| Generate starter code | Automation | AI can produce a draft |
| Test edge cases | Augmentation | AI suggests tests; human runs them |
| Approve claims and final scope | Human-led | Human is accountable |

## Decisions retained by the human
1. Whether the problem is real and important.
2. Whether a rationale claim is supported by evidence.
3. Whether the prototype is safe and ready to present.

---

# Entry 2 — 4D check and delegation map

## 4D check on a real task: draft an explanation for a code snippet

| Decision | Record |
|---|---|
| Delegation | AI drafts a structured explanation. I provide the code and any available commit/PR context, verify sources, and decide what is safe to present. |
| Description | Context: code-understanding tool. Objective: explain likely rationale without inventing intent. Task: separate behaviour, evidence, inference, unknowns, and checks. Constraints: use only supplied material; no claim of repository access or tests. Output: structured explanation. Success criteria: every evidence claim is traceable and uncertainty is visible. |
| Discernment | Compare quoted evidence with the original commit/PR/document; inspect whether inferences are labelled; check that unknowns remain unknown. |
| Diligence | Before using the result, open the cited source, check the code yourself, and remove or relabel unsupported claims. |

## Delegation map
| Task | Owner | Why |
|---|---|---|
| Draft interview script | AI-led, reviewed by me | Easy to evaluate and edit |
| Find and contact actual users | Me-led | Requires real people and consent |
| Summarize interview notes | Shared | AI can cluster; I check against raw notes |
| Decide the core user problem | Me-led | Product decision based on evidence |
| Draft app code | AI-led, reviewed by me | Fast start, but code must be run and tested |
| Verify rationale claims | Me-led/shared | AI cannot independently prove its own claims |
| Test the interface | Me-led | Requires actual execution and observation |
| Final submission | Me-led | I own accuracy and contents |

## Tasks I cannot yet evaluate fully
TODO: list any code, API, security, or research task you do not understand well enough to check. Learn the minimum needed before accepting that output.

## Three review points
1. After research: check every market/problem claim against a source or raw interview note.
2. After generation: compare every claimed evidence fragment against the pasted source.
3. Before submission: run the app and edge-case tests; inspect the ZIP contents.

---

# Entry 3 — Brief and verify

## Six-part brief
- **Context:** I am exploring a tool that helps developers understand unfamiliar code by using repository context.
- **Objective:** Find out whether recovering the rationale behind code decisions is a meaningful, recurring problem for a specific developer group.
- **Task:** Research existing workflows and tools, and identify what evidence supports or contradicts the problem.
- **Constraints:** Prefer primary sources and real user accounts; distinguish current facts from assumptions; do not invent statistics or claim interviews occurred.
- **Output:** A table with claim, source, date, evidence type, confidence, and what remains unknown.
- **Success criteria:** Every factual claim has a traceable source or is explicitly labelled unverified; research leads to a decision about whether to continue, narrow, or change the problem.

## Five questions to ask AI before researching
Prompt: “Before answering, ask me the five questions you most need answered to do this research well.”

TODO: Paste the actual five questions returned and note which decisions you had not made.

## AI research output
TODO: Paste the unedited output actually received. Do not fabricate this section.

## One claim verification
- Claim selected: TODO
- Source opened directly: TODO
- What the source actually says: TODO
- Verification result: supported / partly supported / unsupported
- Decision: keep / qualify / remove

## Tagged claim list
| Claim | Type | Source/status |
|---|---|---|
| Developers may need to reconstruct code rationale | Hypothesis | Must be tested with real users |
| Commit/PR context may help explain code decisions | Hypothesis | Plausible; test with examples |
| The app can know the author's original intention | Assumption / unsupported | Do not claim this |
| Any statistic about developer onboarding or productivity | Unverified until sourced | Find a credible source or omit |

---

# Entry 4 — Unwind the idea

## Five whys
1. Why build a code-rationale explainer? Developers may not understand unfamiliar code.
2. Why is that a problem? They may need to search history, ask teammates, or infer intent.
3. Why does that matter? It could interrupt work or create uncertainty during changes.
4. Why is the interruption significant? Unknown; it depends on frequency, code criticality, and current tools.
5. Why don't existing workflows resolve it? Unknown; requires user interviews and competitor research.

**First research item:** Ask developers about the last real occasion they had to understand why unfamiliar code existed, what they did, how long it took, and what was difficult.

## Two reframes
- **Disbeliever:** Perhaps developers already use IDE tools, commit history, code search, and teammates effectively. The product may add little value.
- **Incumbent:** A maintainer may prefer a human conversation or existing documentation because generated explanations can be wrong.

## Critique from two stakeholders
- **User objection:** “How can I trust the explanation if the model is guessing?”
- **Technical lead objection:** “How will the tool distinguish a commit's stated reason from the model's interpretation?”

These are anticipated objections, not actual interview findings.

## Top three assumptions and 48-hour tests
| Rank | Assumption | 48-hour test |
|---|---|---|
| 1 | Target users encounter this problem often enough | Ask 3 developers about their last concrete example; record actual behaviour |
| 2 | Relevant context is available | Ask participants what artifacts they had: commits, PRs, issues, docs, comments |
| 3 | Evidence-labelled explanations are more useful than a plain summary | Show a simple mock-up to 2 users and ask them to identify supported vs inferred claims |

## Problem statement — Version 2 (provisional)
Developers working in an unfamiliar codebase may struggle to reconstruct the rationale behind a specific implementation decision when the context is spread across code, commits, pull requests, issues, and documentation. They currently search those artifacts, ask colleagues, or infer intent from the code. A useful tool would need to reduce that effort without presenting guesses as facts. This statement remains provisional until supported by real user conversations.

---

# Entry 5 — Research-backed product-market fit

## Falsifiable hypothesis
For developers who have recently worked in an unfamiliar codebase, a tool that combines a code snippet with relevant repository context and clearly separates evidence from inference will help them understand at least one code decision more easily than their current workflow. This is disproved if target users rarely face this problem, already solve it easily, or find the explanation no more useful than their current approach.

## Initial ICP hypothesis
Software engineering interns, junior developers, or open-source contributors who have recently needed to understand a codebase they did not create. Narrow this after interviews.

## Five real examples to contact
TODO: Add five actual people you can reach (with their permission to participate). Do not invent names or claim they agreed.

1. TODO
2. TODO
3. TODO
4. TODO
5. TODO

## Interview questions about past behaviour
1. Tell me about the last time you had to understand why an unfamiliar piece of code was written that way.
2. What were you trying to do at the time?
3. What did you check first?
4. Which sources did you use, and what was missing?
5. Did you ask anyone for help? What happened?
6. How did you decide your understanding was correct?
7. What was the consequence of not understanding it quickly?
8. May I show you a rough prototype and observe how you use it?

Avoid asking only “Would you use this app?” Record actual examples and contradictions.

## Current substitute
Possible substitutes to investigate: code comments, commit history, pull requests, issues, documentation, IDE search, `git blame`, code search, and asking a teammate. These are candidate substitutes, not confirmed interview findings.

## Value mechanism
The prototype combines a code snippet with user-supplied repository context and produces a structured explanation that labels direct evidence, possible interpretations, unknowns, and next verification steps. Its proposed value is easier context reconstruction, not simply “using AI.”

## Opportunity estimate
Do not enter a market size yet. Estimate only after research:
Findable target users × defensible price or value proxy × realistic adoption.
Attach a source or explain the calculation for every number.

## Insight Ledger — add real findings
| Insight | Origin | Type | Confidence | Consequence |
|---|---|---|---|---|
| TODO | Interview/source | Observed / stated / sourced / assumed | Low/medium/high with reason | What would change if true? |
| TODO | Interview/source | Observed / stated / sourced / assumed | Low/medium/high with reason | What would change if true? |

## One flow to build
1. User pastes code.
2. User pastes related commit/PR/issue context if available.
3. Tool drafts an explanation separating evidence, inference, and unknowns.
4. User checks the cited material and records corrections.

---

# Entry 6 — Spec, build, and test

## Specification
See `PROJECT_SPEC.md`.

## Tech stack
- **Language:** Python — accessible for a beginner prototype.
- **UI:** Streamlit — fast to build a simple interactive web interface.
- **Model/API:** Google Gemini API through the `google-genai` Python SDK — generates a structured draft explanation.
- **Input data:** Code and repository context manually supplied by the user.
- **Storage:** None in this MVP.
- **Hosting:** Local demonstration initially; choose a hosted deployment only after checking API-key and data handling.

## Tests to run and record
Do not mark these as passed until you run them.

| Test | Expected result | Actual result |
|---|---|---|
| Normal code + commit context | Structured explanation | TODO |
| Empty code input | Clear validation error | TODO |
| Very long code input | Handles it or displays a clear API/input error | TODO |
| No repository context | Explicitly says rationale is not established | TODO |
| Missing API key | Clear configuration message | TODO |
| Context contains no evidence of intent | Output labels explanations as inference/unknown | TODO |

## Stranger test
Run with two people who have not heard your explanation. Give each this task: “Use the tool to understand why this code decision may have been made. Tell me which statements are directly supported by the provided context.”

| Participant | Hesitation / wrong click / question | What they misunderstood | Change made |
|---|---|---|---|
| Person 1 (consented) | TODO | TODO | TODO |
| Person 2 (consented) | TODO | TODO | TODO |

Do not enter names or identifying details unless necessary and consented.

## Four-part reusable workflow
- **Input:** Code snippet, source-labelled repository context, and a specific question.
- **Process:** Ask the model for behaviour, evidence, inference, unknowns, and verification steps.
- **Verification:** Open the original source; compare quotes; run relevant tests if appropriate; label unsupported claims.
- **Output:** A reviewed explanation with unresolved questions clearly marked.

## Final reflection
TODO: After testing, write what surprised you, what changed, what remains unverified, and whether the evidence supports continuing with this problem.
