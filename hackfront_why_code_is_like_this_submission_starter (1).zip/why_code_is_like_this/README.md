# Why The Code Is Like This
**hackFront Builder Lab — Build with AI: The AI Builder's Operating Kit**

## Project summary
A small developer tool that drafts an explanation of code rationale using a code snippet and repository context supplied by the user (such as commit messages, pull-request notes, or a diff). It must distinguish direct evidence from inference and unknowns. It must not claim to know an author's intention unless the provided sources support that claim.

## Current status
This is a starter prototype. The concept and implementation are not proof of product-market fit. User interviews, source verification, and the stranger test must be completed and documented honestly before final submission.

## Run locally
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Create and activate a virtual environment if desired.
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. Set your Gemini API key as an environment variable:
   - PowerShell: `$env:GEMINI_API_KEY="YOUR_API_KEY"`
   - macOS/Linux: `export GEMINI_API_KEY="YOUR_API_KEY"`
6. Run:
   ```bash
   streamlit run app.py
   ```

Do not commit your API key or upload it in the assessment ZIP. The app does not automatically access GitHub; paste only repository material you are permitted to share.

## Prototype flow
1. Paste a code snippet.
2. Paste related commit/PR/diff context, if available.
3. Ask for an explanation.
4. Review the result, checking each evidence claim against the supplied source.
5. Record unsupported claims as unknown instead of presenting them as facts.

## Limitations
- Explanations can still be wrong or incomplete.
- If no repository history is supplied, the app cannot reliably recover the original rationale.
- Do not paste secrets, credentials, proprietary code, or private repository content without permission.
- The model name can change over time. Set `GEMINI_MODEL` to a model available to your API account if needed.
