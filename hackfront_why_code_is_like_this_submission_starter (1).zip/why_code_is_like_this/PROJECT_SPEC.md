# PROJECT_SPEC.md — Why The Code Is Like This

## 1. What is this?
A small web prototype that drafts explanations of code rationale from a code snippet and user-supplied repository context. It separates direct evidence, inference, and unknowns.

## 2. Who uses it?
Initial target hypothesis: software developers who are new to an existing codebase, including interns, students contributing to open-source projects, and developers maintaining unfamiliar modules. This target must be narrowed after real interviews.

## 3. What must it do?
- Accept a code snippet.
- Accept optional commit, pull-request, issue, documentation, or diff context.
- Generate a structured explanation of observable behaviour, direct evidence, inferences, unknowns, and verification steps.
- Warn that inferred rationale is not the same as confirmed author intent.
- Provide a human verification checklist.
- Show a useful error if required input or API configuration is missing.

## 4. What does it not do?
- It does not automatically clone or inspect a repository.
- It does not claim to know the author's intent without evidence.
- It does not edit code or open pull requests.
- It does not guarantee correctness or replace code review.
- It does not support private repository access or authentication in this MVP.
- It does not claim product-market fit based on this prototype alone.

## 5. What data does it use?
- Code and context manually pasted by the user.
- The text is sent to the configured Gemini API when the user requests an explanation.
- Do not submit secrets, credentials, personal data, or proprietary code without permission.
- API key is read from the `GEMINI_API_KEY` environment variable and must not be committed.

## 6. Constraints
- Beginner-friendly Python implementation.
- Streamlit interface.
- Gemini API access and internet connection required for generation.
- Build scope limited to one primary flow.
- No user database or persistent storage in the MVP.
- User must manually verify any claimed evidence.

## 7. What does done mean?
- App starts locally.
- User can enter code and optional context.
- App returns a structured explanation when valid API credentials are available.
- Missing code and missing API key produce clear messages.
- Test notes record normal input, empty input, long input, and unsupported input.
- At least two people attempt the flow without coaching, and their observations are recorded honestly.
- Known limitations and unresolved risks are documented.

## 8. What is still unknown?
- How often target users need to recover code rationale.
- Which context source is most useful: commit history, PRs, issues, docs, or code comments.
- Whether users trust an explanation when evidence is sparse.
- Whether the output saves enough time to justify using the tool.
- Which existing tools already solve this well.
- Whether users prefer a pasted-context MVP or direct repository integration.
